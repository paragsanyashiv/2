#include"omp.h"
#include"iostream"
using namespace std;

int a[65536],s,test;
int global_size,global_x,n=4;
void nary_search(int,int);
int main()
{
	int size=65536,x=0;
	for(int i=0;i<size;i++)
		a[i]=i*2;
	cout<<"\nenter the no. to be searched";
	cin>>s;
	nary_search(size,x);
}
void nary_search(int size,int x)
{
     cout<<size;
	if(size<=4)
	{
	test=0;
# pragma omp parallel
		{
			int tid=omp_get_thread_num();
			if(a[global_x+tid]==s)
			{
                       cout<<"found at \n"<<global_x+tid;
				test=1;
			}
		}
           if(test==0)
		{
            cout<<"not found\n";
		}
	}
	else
	{
		test=0;
#pragma omp parallel
	  {
		  int tid=omp_get_thread_num();
		  cout<<"checking ("<<a[tid*size/n+x] <<"--"<<a[tid*size/n+size/n-1+x]<<")with thread "<<tid<<" on cpu "<<sched_getcpu()<< "\n";
		  if(s>=a[tid*size/n+x] && s<=a[tid*size/n+size/n-1+x])
		  {
			  cout<<"may be here "<<a[tid*size/n+x] <<" -"<<a[tid*size/n+size/n-1+x]<<"size=("<<+size<<")\n";
			  				global_size=size/n;
			  				global_x=tid*global_size+x;
			  				test=1;
		  }
}
if(test==1)
	{
		nary_search(global_size,global_x);
	}
	else
	{
		cout<<"not found";
	}

	}
}
