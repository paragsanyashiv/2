
#include<stdio.h>
#include<omp.h>
#include<time.h>
omp_lock_t lock;

void Reader(int tid)
{
 int a;
 //Wait till there is lock 
 while (!omp_test_lock(&lock))
 {
  printf("\nReader : %d is waiting ", tid);
 }
 omp_unset_lock(&lock); //No need of lock for reading

 printf("\nReader : %d is reading", tid);

 sleep(3);
}

void Writer(int tid)
{
 //First get the lock
 while (!omp_test_lock(&lock))
 {
  printf("\nWriter : %d is waiting ", tid);
 }
 printf("\nWriter : %d acquired lock", tid); 
 printf("\nWriter : %d is writing", tid);
 //perform operation on the shared data

 omp_unset_lock(&lock); //release the lock after writing
 printf("\nWriter : %d released lock", tid);
 sleep(2);
}
int main()
{

 int no, tid;
 omp_init_lock(&lock);
 srand((unsigned)time(NULL)); 
 int totalthreads;
 #pragma omp parallel private(tid) shared(totalthreads)
 {
  totalthreads = omp_get_num_threads();

  while(1)
  {
   int randomno = rand() % 100;
   //Getting thread ID
   tid = omp_get_thread_num();
   // half of threads are readers and half are writers   
   
   if(randomno < 50) {   //calling reader 
    printf("\nProcess no. %d is a reader ", randomno);
    Reader(randomno);
   }

   else {       //calling writer
    printf("\nProcess no. %d is a writer ", randomno);
    Writer(randomno);
 }}}}
