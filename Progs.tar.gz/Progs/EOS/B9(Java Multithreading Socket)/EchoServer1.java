import java.io.*;
import java.net.*;
import java.lang.Thread;
 
public class EchoServer1 {
  public static void main (String[] args) {
    
	// The default port number.
    int portNumber = 2222;
    if (args.length < 1) {
      System.out.println("Usage: java MultiThreadChatServer <portNumber>\n"
              + "Now using port number=" + portNumber);
    } else {
      portNumber = Integer.valueOf(args[0]).intValue();
    }

    /*
     * Open a server socket on the portNumber (default 2222). Note that we can
     * not choose a port less than 1023 if we are not privileged users (root).
     */


   try {

	/*
     * Create a client socket for each connection and pass it to a new client
     * thread.
     */
      ServerSocket server = new ServerSocket(portNumber);
      while (true) {
        Socket client = server.accept();
        EchoHandler handler = new EchoHandler(client);
        handler.start();
      }
    }
    catch (Exception e) {
      System.err.println("Exception caught:" + e);
    }
  }
}
 
class EchoHandler extends Thread {
  Socket client;
  EchoHandler (Socket client) {
    this.client = client;
  }
 
  public void run () {
    try {
      BufferedReader reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
      PrintWriter writer = new PrintWriter(client.getOutputStream());
     // writer.println("[type 'Ok' to disconnect]");
 
      while (true) {
        String line = reader.readLine();
	System.out.println("from Client " +line);
        if (line.trim().equals("Ok")) {
          writer.println("Ok!");
          break;
	
        }
        writer.println("Server Says[echo] : " + line);
	writer.flush();
      }
       reader.close();
       writer.close();
     }
    catch (Exception e) {
      System.err.println("Exception caught: client disconnected.");
    }
    finally {
      try { client.close();
	    
	  }
      catch (Exception e ){ ; }
    }
  }
}
