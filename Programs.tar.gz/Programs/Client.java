import java.io.*;
import java.net.*;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int port=2226;
		String host="192.168.2.3";
		Socket client=null;
		DataInputStream is=null;
		PrintWriter ps=null;
		DataInputStream inputLine=null;
		if(args.length<2)
		{
			System.out.println("Usage:javaMultiThreadChatClient<host><port number>\n"+"Now using host="+host+", port number="+port);
		}
		else
		{
			host=args[0];
			port=Integer.valueOf(args[1]).intValue();
		}
		try{
			client=new Socket(host, port);
			ps=new PrintWriter(client.getOutputStream());
			is=new DataInputStream(client.getInputStream());
			inputLine=new DataInputStream(new BufferedInputStream(System.in));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		if(client!=null && ps!=null && is!=null)
		{
			try{
				System.out.println("The client has started. Type any text. Type 'OK' to quit");
				String responseLine;
				ps.println(inputLine.readLine());
				while((responseLine=is.readLine())!=null)
				{
					System.out.println(responseLine);
					if(responseLine.indexOf("OK")!=-1)
					{
						break;
					}
					ps.println(inputLine.readLine());
				}
				ps.close();
				is.close();
				client.close();
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
