#!/usr/bin/python 
##########################################################
# * Python code (Adafruit BBIO Library Version) for  
# * Lift Operation Simulation using Beaglebone Black  
# * running Debian 7 Linux distribution
##########################################################
# * Developed by MicroEmbedded Technologies
##########################################################

# Import standard python libraries
import os
import time

# Import GPIO part of Adafruit BBIO Library
import Adafruit_BBIO.GPIO as GPIO

##############################################################
# GPIO Pin definitions for Lift Simulation Board 
# Please refer "MicroEmbedded_BBB_Interfacing Details_New.pdf" 
# for all the PIN details
##############################################################

DIR_LED_1 	= "P9_11"
DIR_LED_2 	= "P8_7"
DIR_LED_3 	= "P9_12"
DIR_LED_4 	= "P8_8"
DIR_LED_5 	= "P9_13"
DIR_LED_6 	= "P8_9"
DIR_LED_7 	= "P9_14"

POS_LED_0	= "P9_23"
POS_LED_1	= "P8_15"
POS_LED_2	= "P9_24"
POS_LED_3	= "P8_16"

LIFT_LED_0	= "P9_21"
LIFT_LED_1	= "P8_13"
LIFT_LED_2	= "P9_22"
LIFT_LED_3	= "P8_14"

BUTTON_0 	= "P9_26"
BUTTON_1 	= "P8_17"
BUTTON_2 	= "P8_19"
BUTTON_3 	= "P8_18"


# An array of DIRECTION LEDS 
dir_leds = [ 	DIR_LED_1,
		DIR_LED_2,
		DIR_LED_3,
		DIR_LED_4,
		DIR_LED_5,
		DIR_LED_6,
		DIR_LED_7
	   ]	

# An array of POSITION LEDS 
pos_leds = [
		POS_LED_0,
		POS_LED_1,
		POS_LED_2,
		POS_LED_3
	   ]

# An array of LIFT LEDS
lift_leds = [
		LIFT_LED_0,
		LIFT_LED_1,
		LIFT_LED_2,
		LIFT_LED_3
	   ]

# Default position of the Lift  (LED for Ground Floor)
DEFAULT_LIFT_POS = POS_LED_0
# No of LEDs for showing the lift direction
NO_OF_DIR_LEDS	 =	7

##############################################################
# Description 	: This function turns the LED ON 
# 		  It will setup a PIN as GPIO, sets the 
# 		  direction as OUT and then makes the PIN high  
# Input		: @pin = Pin No associated with LED
# Return	: None	 
# Note		: 
##############################################################

def liftLEDOn(pin):
	GPIO.setup(pin, GPIO.OUT)
	GPIO.output(pin, GPIO.HIGH)
	return 

##############################################################
# Description 	: This function turns the LED OFF 
# 		  It will setup a PIN as GPIO, sets the 
# 		  direction as OUT and then makes the PIN low  
# Input		: @pin = Pin No associated with LED 
# Return	: None	 
##############################################################
	
def liftLEDOff(pin):
	GPIO.setup(pin, GPIO.OUT)
	GPIO.output(pin, GPIO.LOW)
	return 

##############################################################
# Description 	: This function sets up a Lift button for input 
# 		  It will setup a PIN as GPIO, sets the 
# 		  direction as IN and then add the event to be 
# 		  detected on falling edge of the GPIO Pin		  
# Input		: @pin = Pin No associated with Lift button 
# Return	: None	 
##############################################################

def setupButton(pin):
	GPIO.setup(pin, GPIO.IN)
	GPIO.add_event_detect(pin, GPIO.FALLING)
	return 

##############################################################
# Description 	: This function glows the direction LEDs in 
#	   	  upward direction to indicate lift going UP  
# Input		: None 
# Return	: None	 
##############################################################

def liftDirUp():
	for i in range(0, NO_OF_DIR_LEDS):
		liftLEDOn(dir_leds[i])
		time.sleep(0.5)
	for i in range(0, NO_OF_DIR_LEDS):
		liftLEDOff(dir_leds[i])
	return

################################################################
# Description 	: This function glows the direction LEDs in 
#	   	  downward direction to indicate lift going DOWN   
# Input		: None 
# Return	: None	 
################################################################

def liftDirDown():
	for i in range(NO_OF_DIR_LEDS, 0, -1):
		liftLEDOn(dir_leds[i-1])
		time.sleep(0.5)
	for i in range(0, NO_OF_DIR_LEDS):
		liftLEDOff(dir_leds[i])
	return


##############################################################
# Description 	: This function will initialize Lift buttons 
#	   	  and LEDs. Must be called at the starting of    
# 		  the program		  
# Input		: None 
# Return	: None	 
##############################################################
	
def liftInitAll():
	setupButton(BUTTON_0)		# Setup all lift Buttons
	setupButton(BUTTON_1)
	setupButton(BUTTON_2)
	setupButton(BUTTON_3)
	
	liftLEDOff(DIR_LED_1)		# Initialize all lift LEDs
	liftLEDOff(DIR_LED_2)
	liftLEDOff(DIR_LED_3)
	liftLEDOff(DIR_LED_4)
	liftLEDOff(DIR_LED_5)
	liftLEDOff(DIR_LED_6)
	liftLEDOff(DIR_LED_7)
	
	liftLEDOff(POS_LED_0)		
	liftLEDOff(POS_LED_1)
	liftLEDOff(POS_LED_2)
	liftLEDOff(POS_LED_3)
	
	liftLEDOff(LIFT_LED_0)
	liftLEDOff(LIFT_LED_1)
	liftLEDOff(LIFT_LED_2)
	liftLEDOff(LIFT_LED_3)
	
	liftLEDOn(DEFAULT_LIFT_POS)	# LED for DEFAULT_LIFT_POS is Turned ON. Defined as 0th (Ground Floor)
	return
	
############################################################################
# Description 	: This function will return the floor no at  
#		  which lift button is pressed. It will check the button 
#		  press event for each floor and retrun the floor no for 
#		  which event is detected. Also turn ON the associated 
#		  indication lift LED 			 			  
# Input		: None 
# Return	: None	 
#############################################################################

def GetButtonVal():
	while True:
		if GPIO.event_detected(BUTTON_0):
			liftLEDOn(LIFT_LED_0)
			return 0
		elif GPIO.event_detected(BUTTON_1):
			liftLEDOn(LIFT_LED_1)
			return 1
		elif GPIO.event_detected(BUTTON_2):
			liftLEDOn(LIFT_LED_2)
			return 2
		elif GPIO.event_detected(BUTTON_3):
			liftLEDOn(LIFT_LED_3)
			return 3
			
######################## 
# Program starts here
########################	
		
liftInitAll()				# Initialize all lift Buttons and LEDs		
time.sleep(1)				# Sleep for 1 second	
cur_flr = 0				# Variable for current lift floor (initially 0)
while True:				
	new_flr = GetButtonVal()	# Get a new floor value by detecting a floor no to which button user calls the lift  
	if new_flr > cur_flr:				# if (new floor > current floor) means lift is called to upper floor
		tmp = cur_flr					# store current floor no into tmp variable
		print "LIFT going UP to floor #%d" %new_flr	# print destination floor
		while (tmp != new_flr):				# Use tmp value (incremental); till it becomes destination 
			liftDirUp()				# Glow direction LEDs in upward direction
			time.sleep(0.01)			# sleep for 10 ms
			liftLEDOff(pos_leds[tmp])		# Turn off position LED at the floor pointed by tmp 
			tmp += 1				# Increment tmp value by 1
			liftLEDOn(pos_leds[tmp])		# Turn ON position LED at the floor pointed by tmp. Lift is one floor UP
			time.sleep(0.5)				# Sleep for 0.5 second (500 ms)
	elif new_flr < cur_flr:				# if (new floor < current floor) means lift is called to lower floor
		tmp = cur_flr					# store current floor no into tmp variable
		print "LIFT going DOWN to floor #%d" %new_flr	# print destination floor
		while (tmp != new_flr):				# Use tmp value (decremental); till it becomes destination
			liftDirDown()				# Glow direction LEDs in downward direction
			time.sleep(0.01)			# Sleep for 10 ms
			liftLEDOff(pos_leds[tmp])		# Turn off position LED at the floor pointed by tmp
			tmp -= 1				# Decrement tmp value by 1
			liftLEDOn(pos_leds[tmp])		# Turn ON position LED at the floor pointed by tmp. Lift is one floor DOWN
			time.sleep(0.5)				# sleep for 0.5 second (500 ms)
	
	cur_flr = new_flr		# Once lift reaches the destination; current floor points to destination floor no 
	liftLEDOff(lift_leds[new_flr])	# Turn OFF button press indication LED of the destinaton floor
	time.sleep(1)			# Sleep for 1 second
exit()					# Exit the Program

	

