import os
import time
import sys
import Adafruit_BBIO.GPIO as GPIO

STEPPER_1="P9_11"
STEPPER_2="P8_7"
STEPPER_3="P9_12"
STEPPER_4="P8_8"

def stepperOn(pin):
	GPIO.setup(pin, GPIO.OUT)
	GPIO.setup(pin, GPIO.HIGH)
	return

def stepperOff(pin):
	GPIO.setup(pin, GPIO.OUT)
	GPIO.setup(pin, GPIO.LOW)
	return

def stepperSeq5():
	stepperOn(STEPPER_1)
	time.sleep(1)
	stepperOff(STEPPER_2)
	time.sleep(1)
	stepperOn(STEPPER_3)
	time.sleep(1)
	stepperOff(STEPPER_4)
	time.sleep(1)
	return

def stepperSeq9():
	stepperOn(STEPPER_1)
	time.sleep(1)
	stepperOff(STEPPER_2)
	time.sleep(1)
	stepperOff(STEPPER_3)
	time.sleep(1)
	stepperOn(STEPPER_4)
	time.sleep(1)
	return

def stepperSeq10():
	stepperOff(STEPPER_1)
	time.sleep(1)
	stepperOn(STEPPER_2)
	time.sleep(1)
	stepperOff(STEPPER_3)
	time.sleep(1)
	stepperOn(STEPPER_4)
	time.sleep(1)
	return

def stepperSeq6():
	stepperOff(STEPPER_1)
	time.sleep(1)
	stepperOn(STEPPER_2)
	time.sleep(1)
	stepperOn(STEPPER_3)
	time.sleep(1)
	stepperOff(STEPPER_4)
	time.sleep(1)
	return

def stepperDirLeft():
	stepperSeq9()
	time.sleep(0.1)
	stepperSeq5()
	time.sleep(0.1)
	stepperSeq6()
	time.sleep(0.1)
	stepperSeq10()
	time.sleep(0.1)
	return

def stepperDirRight():
	stepperSeq10()
	time.sleep(0.1)
	stepperSeq6()
	time.sleep(0.1)
	stepperSeq5()
	time.sleep(0.1)
	stepperSeq9()
	time.sleep(0.1)
	return

print "\n Stepper Motor Driver using Python\n"
print "------------------------------------\n"
while True:
	for i in range(0,12):
		stepperDirLeft()
		print "THE MOTOR IS ROTATING ANTICLOCKWISE"
	time.sleep(1.5)
	
	for i in range(0,12):
		stepperDirRight()
		print "THE MOTOR IS ROTATING CLOCKWISE"
	time.sleep(1.5)

exit()
