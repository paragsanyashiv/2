import os
import time
import Adafruit_BBIO.GPIO as GPIO

DIR_LED_1="P9_11"
DIR_LED_2="P8_7"
DIR_LED_3="P9_12"
DIR_LED_4="P8_8"
DIR_LED_5="P9_13"
DIR_LED_6="P8_9"
DIR_LED_7="P9_14"

POS_LED_0="P9_23"
POS_LED_1="P8_15"
POS_LED_2="P9_24"
POS_LED_3="P8_16"

LIFT_LED_0="P9_21"
LIFT_LED_1="P8_13"
LIFT_LED_2="P9_22"
LIFT_LED_3="P8_14"

BUTTON_0="P9_26"
BUTTON_1="P8_17"
BUTTON_2="P8_19"
BUTTON_3="P8_18"

dir_leds = [
		DIR_LED_1
		DIR_LED_2
		DIR_LED_3
		DIR_LED_4
		DIR_LED_5
		DIR_LED_6
		DIR_LED_7
	]

pos_leds = [
		POS_LED_0
		POS_LED_1
		POS_LED_2
		POS_LED_3
	]

lift_leds = [
		LIFT_LED_0
		LIFT_LED_1
		LIFT_LED_2
		LIFT_LED_3
	]

DEFAULT_LIFT_POS = POS_LED_0
NO_OF_DIR_LEDS = 7

def liftLEDOn(pin):
	GPIO.setup(pin, GPIO.OUT)
	GPIO.setup(pin, GPIO.HIGH)
	return

def liftLEDOff(pin):
	GPIO.setup(pin, GPIO.OUT)
	GPIO.setup(pin, GPIO.LOW)
	return

def setupButton(pin):
	GPIO.setup(pin, GPIO.IN)
	GPIO.add_event_detected(pin, GPIO.FALLING)
	return

def liftDirUp():
	for i in range(0,NO_OF_DIR_LEDS):
		liftLEDOn(dir_leds[i])
		time.sleep(0.5)
	for i in range(0,NO_OF_DIR_LEDS):
		liftLEDOff(dir_leds[i])
	return

def liftDirDown():
	for i in range(NO_OF_DIR_LEDS,0,-1):
		liftLEDOn(dir_leds[i-1])
		time.sleep(0.5)
	for i in range(0,NO_OF_DIR_LEDS):
		liftLEDOff(dir_leds[i])
	return

def liftInitAll():
	setupButton(BUTTON_0)
	setupButton(BUTTON_1)
	setupButton(BUTTON_2)
	setupButton(BUTTON_3)

	liftLEDOff(DIR_LED_1)
	liftLEDOff(DIR_LED_2)
	liftLEDOff(DIR_LED_3)
	liftLEDOff(DIR_LED_4)
	liftLEDOff(DIR_LED_5)
	liftLEDOff(DIR_LED_6)
	liftLEDOff(DIR_LED_7)

	liftLEDOff(POS_LED_0)
	liftLEDOff(POS_LED_1)
	liftLEDOff(POS_LED_2)
	liftLEDOff(POS_LED_3)

	liftLEDOff(LIFT_LED_0)
	liftLEDOff(LIFT_LED_1)
	liftLEDOff(LIFT_LED_2)
	liftLEDOff(LIFT_LED_3)

	liftLEDOn(DEFAULT_LED_POS)
	return

def getButtonVal():
	while True:
		if GPIO.event_detected(BUTTON_0):
			liftLEDOn(LIFT_LED_0)
			return 0
		if GPIO.event_detected(BUTTON_1):
			liftLEDOn(LIFT_LED_1)
			return 1
		if GPIO.event_detected(BUTTON_2):
			liftLEDOn(LIFT_LED_2)
			return 2
		if GPIO.event_detected(BUTTON_3):
			liftLEDOn(LIFT_LED_3)
			return 3

liftInitAll()
time.sleep(1)
cur_flr = 0
while True:
	new_flr=getButtonVal()
	if new_flr > cur_flr:
		temp=cur_flr
		print "LIFT IS GOING UP TO FLOOR #%d" %new_flr
		while (temp!=new_flr):
			liftDirUp()
			time.sleep(0.01)
			liftLEDOff(pos_leds[temp])
			temp += 1
			liftLEDOn(pos_leds[temp])
			time.sleep(0.5)

	elif new_flr < cur_flr:
		temp=cur_flr
		print "LIFT IS GOING DOWN TO FLOOR #%d" %new_flr
		while (temp!=new_flr):
			liftDirDown()
			time.sleep(0.01)
			liftLEDOff(pos_leds[temp])
			temp -= 1
			liftLEDOn(pos_leds[temp])
			time.sleep(0.5)

	cur_flr=new_flr
	liftLEDOff(lift_leds[new_flr])
	time.sleep(1)

exit()
