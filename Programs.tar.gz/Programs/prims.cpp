#include<iostream>
#include"stdlib.h"
#include"omp.h"

#define true 1
#define false 0
using namespace std;
int nodes,cost[10][10],i,j,visited[10],vis=1,sum=0,x,y;

int main()
{
	int m=999,c;
	cout<<"Enter the no of nodes: "<<endl;
	cin>>nodes;
	for(i=1;i<=nodes;i++)
	{
		for(j=1;j<=nodes;j++)
		{
			cout<<"Enter the cost from"<< i <<" to "<< j<<": ";
			cin>>c;
			cost[i][j]=c;
		}
	}

	visited[1]=true;
	cout<<"Minimum spanning tree is:"<<endl;
	while(vis<nodes)
	{
		#pragma omp parallel for
			for(i=1;i<=nodes;i++)
			{
				if(visited[i]==true)
					{
						for(j=1;j<=nodes;j++)
						{
							if((cost[i][j]<=m && cost[i][j]!=0) && (visited[j]==false))
							{
								m=cost[i][j];
								x=i;
								y=j;
							}
						}
					}
			}
		vis=vis+1;
		sum=sum+m;
		cout<<x<<"====>"<<y<<"\t cost: "<<cost[x][y]<<endl;
		visited[y]=true;
		m=999;
	}
	cout<<"The cost of minimum spanning tree is: "<<sum<<endl;
	return 0;
}
